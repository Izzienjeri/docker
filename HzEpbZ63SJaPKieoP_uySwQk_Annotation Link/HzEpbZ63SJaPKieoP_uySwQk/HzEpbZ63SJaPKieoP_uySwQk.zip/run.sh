#!/bin/bash

pytest eval.py